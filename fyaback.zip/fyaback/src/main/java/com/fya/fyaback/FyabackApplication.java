package com.fya.fyaback;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FyabackApplication {

	public static void main(String[] args) {
		SpringApplication.run(FyabackApplication.class, args);
	}

}
